class Robot {
public:
    void init();
    void update();
};