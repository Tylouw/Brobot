#include <Arduino.h>
#include "robot.h"
#include "hardware/hardware_init.h"
#include "motion/stepper_motor.h"
#include "config/pin_config.h"
#include "utils/debug.h"

StepperMotor motor{ static_cast<uint8_t>(STEPPER_PINS[2].step),
                    static_cast<uint8_t>(STEPPER_PINS[2].dir),
                    STEPS_PER_REV };

void Robot::init() {
    debug_init();
    LOG_INFO("Robot init starting");
    initPins();
    initMotors();
    // disableMotors();
    motor.move(6.0f, 0.7f, 1.0f);
}

void Robot::update() {
    motor.update();
    if (!motor.isRunning()) {
        DBG_PRINTLN(motor.positionUnits());
    }
}