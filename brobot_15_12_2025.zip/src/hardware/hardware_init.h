#include <Arduino.h>
#include "config/pin_config.h"

void initPins() {
    pinMode(ESTOP_PIN, INPUT_PULLUP);
    pinMode(SR_DATA_PIN, OUTPUT);
    pinMode(SR_CLOCK_PIN, OUTPUT);
    pinMode(SR_LATCH_PIN, OUTPUT);
}

void sendSerialBits(int value){
  for (int i = 11; i < 32; i++) {
    digitalWrite(SR_DATA_PIN, (value & (1 << i)) > 0 );
    // Serial.print((value & (1 << i)) > 0);
    digitalWrite(SR_CLOCK_PIN, HIGH);
    // delayMicroseconds(30);
    digitalWrite(SR_CLOCK_PIN, LOW);
  }
  // Serial.println();
  digitalWrite(SR_LATCH_PIN, HIGH);
  digitalWrite(SR_LATCH_PIN, LOW);
}

void initMotors(){
    //M2: MS1,MS2,MS3,EN: 0100
    //M1: MS1,MS2,MS3,EN: 0100
    //M4: MS1,MS2,MS3,EN: 0100
    //M3: MS1,MS2,MS3,EN: 0100
    //M5: MS3,EN,MS1,MS2: 0001
    //M6: EN: 0
    //0b01000100010001000001000000000000 - enable motors
    //0b01010101010101010101000000000000 - disable motors
    sendSerialBits(0b01000100010001000001000000000000);
}

void disableMotors(){
    sendSerialBits(0b01010101010101010101000000000000);
}